package com.example.springBootWebApp;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ApplicationController {
	@RequestMapping("/")
	public String welcome() {
		System.out.println("->welcome()");
		return "index";
	}
	
	@RequestMapping("/list_contact")
	public String listContact(Model model) {
		ContactBusiness business = new ContactBusiness();
		List<Contact> contactList = business.getContactList() ;
		model.addAttribute("contacts",contactList);
		return "contact";
	}
	@RequestMapping("/list_student")
	public String listStdent(Model model) {
		StudentBusiness business = new StudentBusiness();
		List<Student> studentList = business.getStudentList();
		model.addAttribute("students",studentList);
		return "student";
	}
}
