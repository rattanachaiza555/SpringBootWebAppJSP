package com.example.springBootWebApp;
public class Student {
	private int id;
    private String name; 
    public Student() {
        super();
    }
    public Student(int id,String name) {
        super();
        this.setId(id);
        this.setName(name);
    }
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	} 
}